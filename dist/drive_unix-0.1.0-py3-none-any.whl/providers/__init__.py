"""Storage provider implementations."""
